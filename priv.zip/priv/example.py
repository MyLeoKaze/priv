
def shell():
    def scan(url, directory_file):
        try:
            with open(directory_file, 'r') as file:
                directories = file.read().splitlines()

            if not url.endswith('/'):
                url += '/'

            found_shells = []

            # Melakukan pemindaian direktori
            for directory in directories:
                directory_url = url + directory
                response = requests.get(directory_url)

                if response.status_code == 200:
                    print(warna(f"[+] Shell : {directory_url} => Found", Fore.LIGHTGREEN_EX))
                    found_shells.append(directory_url)
                elif response.status_code == 404:
                    print(warna(f"[-] Shell : {directory_url} => Not Found", Fore.RED))
                else:
                    print(warna(f"[?] Error accessing {directory_url}: {response.status_code}", Fore.RED))

            return found_shells

        except Exception as e:
            print(warna(f"Error: {str(e)}", Fore.RED))
            return []

    def warna(text, color):
        return f"{color}{text}"

    website_url = input(warna("Enter the website URL: ", Fore.LIGHTGREEN_EX))
    
    with open(website_url, 'r') as url_file:
        websites = url_file.read().splitlines()

    # Memindai setiap situs web dalam daftar
    for website_url in websites:
        directory_file = "files/path.txt"
        found_shells = scan(website_url, directory_file)

        if found_shells:
            download_option = input(warna("Do you want to download the found shells? (yes/no): ", Fore.LIGHTGREEN_EX))
            if download_option.lower() == "yes":
                # Download hasil pemindaian
                download_results(found_shells)
            else:
                print(warna("Results not downloaded.", Fore.YELLOW))
def download_results(found_shells):
    try:
        download_dir = "Found"
        if not os.path.exists(download_dir):
            os.makedirs(download_dir)

        download_log_path = os.path.join(download_dir, "found_shell.txt")

        with open(download_log_path, 'w') as download_log:
            for shell_url in found_shells:
                response = requests.get(shell_url)
                if response.status_code == 200:
                    # Ekstrak nama file dari URL
                    file_name = shell_url.split("/")[-1]
                    file_path = os.path.join(download_dir, file_name)

                    with open(file_path, 'wb') as file:
                        file.write(response.content)
                    download_log.write(f"Found Shell: {shell_url} => {file_name}\n")
                else:
                    download_log.write(f"Failed to download: {shell_url} (Status Code: {response.status_code})\n")

        print(f"Download log saved to: {download_log_path}")

    except Exception as e:
        print(f"Error during download: {str(e)}")