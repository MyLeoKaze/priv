from lib.BruteForce.wp_single_brute import *

run()