import requests
import os
import re
from colorama import Fore, Style, init
init()

#Colors

reset = Style.RESET_ALL
magenta = Fore.LIGHTMAGENTA_EX
red = Fore.RED
green = Fore.LIGHTGREEN_EX
yellow = Fore.LIGHTYELLOW_EX

#Save

def save(url, user, passwd):
    result_folder = 'result/'

    if not os.path.exists(result_folder):
        os.makedirs(result_folder)

    filename = os.path.join(result_folder, f'{url.replace("https://", "").replace("http://", "").replace("/", "_")}_results.txt')

    with open(filename, 'a') as file:
        file.write(f"Username: {user}\nPassword: {passwd}\n\n")

    print(f"{magenta}[{green}+{magenta}]{reset} Result saved to: {green}{filename}{reset}")
    return True

#ReadPasswd
def r_file(file_name):
    try:
        with open(file_name, "r") as file:
            passwords = file.read().splitlines()
            return passwords
    except Exception as e:
        print(f"{magenta}[{red}-{magenta}]{reset} Failed To Load File {file_name}: {str(e)}")
        return []


